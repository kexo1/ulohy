# SPLITNE SLOVO NA MENO A SERVER
s = input('Zadajte emailovú adresu: ').split('@')

# SPLITNE SERVER PODLA BODIEK ČIŽE TO BUDE ['mail', 'pythonsoftware', 'net']
server = s[1].split('.')

# TDL PODLA POSLEDNÉHO SLOVA V LISTE, SERVER PODLA ROZDELENEJ PREMENNEJ s
print(f'TDL: .{server[len(server)-1]}\nServer: {s[1]}\nUser: {s[0]}\nDomény:')

# PRINTNE LIST server
for i in range(len(server)): print(f'Doména {i+1}. úrovne je: ' + server[i])
