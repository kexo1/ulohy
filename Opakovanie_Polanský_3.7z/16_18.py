s = input('Zadajte rodné číslo: ')

# PREMENNÚ DEŇ SI ZÍSKAM SLICNUTÍM s NA DANEJ POZÍCIÍ DÁTUMU
den = s[4:6]

# AK TAM JE 0 PRED DÁTUMOM, TAK SA ODSTRÁNI
if den[0] == '0':
    den = den[1:]

# PREMENNÚ MESIAC SI ZÍSKAM SLICNUTÍM s NA DANEJ POZÍCIÍ MESIACA
mesiac = s[2:4]

# AK MÁ MESIAC NAD 12 TAK POHLAVIE JE ŽENA, INAK MUŽ
if int(mesiac) > 12:
    mesiac = int(mesiac) - 50
    print('Pohlavie: Žena')
else:
    print('Muž')

# ROK JE TIEŽ CEZ SLICE, PRIDÁ TAM 19 ABY BOL VYPÍSANÝ CELÝ ROK
print(f'Dátum narodenia: {den}.{mesiac}.19{s[0:2]}')
