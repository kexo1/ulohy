s = input('Zadaj slovo: ')
for i in range(len(s)):
    # PODOBNE AKO MINULÝ PRÍKLAD, ZO SLICOM OTOČÍM NAOPAK LAVÉ SLOVO KTORÉMU PRIBÚDAJÚ PÍSMENKA NAOPAK, DRUHÉMU PRIDÁVA PÍSMENKA ZARADOM
    print('.' * (len(s) - i) + s[i:: - 1] + s[:i + 1] + '.' * (len(s) - i))
