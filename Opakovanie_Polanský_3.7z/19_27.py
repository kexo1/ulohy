# Cézarova_šifra
vstup = input('Zadaj text: ')
posun = [2, 3]

# POSUN O KOLKO ZOBERIE S LISTU
for kolko in posun:
    desifra = ''

    # PÍSMENKO PO PÍSMENKU
    for znak in vstup:
        # ZNAK KTORÝ BUDE POSUNUTÝ
        novyznak = znak

        # AK SA PÍSMENKO NACHÁDZA V TOMTO ROZMEDZÍ S ODPOČÍTANOU HODNOTOU kolko
        if 97 <= ord(znak) - kolko <= 122:
            novyznak = chr(ord(znak) - kolko)
        # INAK PÍSMENKO BUDE OD KONCA ABECEDY S ODČÍTANOU HODNOTOU kolko
        else:
            # VYPOČÍTA KOLKO MÁ ODPOČÍTAŤ OD PÍSMENA z (122)
            novyznak = chr(123 - (97 - (ord(znak) - kolko)))
        desifra += novyznak
    print(f'Posun o {kolko}: {desifra}')
