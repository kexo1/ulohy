import tkinter

canvas = tkinter.Canvas(height=100, width=500)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()

# ZAČ. HODNOTY PRE PÍSMENKÁ
x = 20


def text():
    global x
    veta = entry1.get()
    # SLICNEM PÍSMENKO SLOVA PODLA TOHO O KOĽKO SA X ZVAČŠILO, ČIŽE AK 40/20 == 2 - 1 TAK DRUHÉ PÍSMENKO
    canvas.create_text(x, 50, text=veta[(x // 20) - 1], font='Arial 20', fill='Blue')
    x += 20

    # AK HODNOTA X DELENÁ 20 MÁ MENŠIU HODNOTU AKO POČET PÍSMENOK V SLOVE TAJ VYKRESLI ĎALŠIE
    if x // 20 <= len(veta): canvas.after(1000, text)


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
