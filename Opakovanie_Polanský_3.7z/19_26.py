# Cézarova_šifra
vstup = input('Zadaj text: ')
sifra = ''

# PÍSMENKO PO PÍSMENKU
for znak in vstup:
    # ZNAK KTORÝ BUDE POSUNUTÝ
    novyznak = znak

    # AK SA PÍSMENKO NACHÁDZA V TOMTO ROZMEDZÍ S ODPOČÍTANOU HODNOTOU 1
    if 'a' <= chr(ord(znak) - 1) <= 'y':
        novyznak = chr(ord(znak) - 1)
    # INAK PÍSMENKO BUDE Z
    if znak == 'a':
        novyznak = 'z'
    # PRIDÁ POSUNUTÝ ZNAK
    sifra += novyznak
print(f'Posun o 1: {sifra}')
