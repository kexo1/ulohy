import random
import tkinter

canvas = tkinter.Canvas(height=100, width=500)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()

# ZAČ. HODNOTA X POZÍCIE
x = 20


def text():
    global x
    x = 20
    canvas.delete('all')
    veta = str(entry1.get())
    for i in range(len(veta)):
        # VYPÍŠE PÍSMENKO PO PÍSMENKU A PRE KAŽDÉ JE RANDOM FARBA Z LISTU
        canvas.create_text(x, 35, text=veta[i], font='Arial 20 bold',
                           fill=random.choice(['blue', 'green', 'lime', 'red', 'black', 'orange']))
        # POSUNIE SA X PRE ĎALŠIE PÍSMENKO
        x += 20


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
