import random
s = ''

# VYBERIE KTORÉ PÍSMENKO BUDE VELKÉ
r = random.randint(0, 7)

for i in range(8):
    # VYTVORÍ RANDOM HESLO S MALÝMI PÍSMENKAMI
    s += chr(random.randint(ord('a'), ord('z')))

# POMOCOU SLICOV ZMENÍ PÍSMENKO NA VEĽKÉ NA RANDOM POZÍCIÍ r
s = s[:r] + s[r:r+1].upper() + s[r+1:]
