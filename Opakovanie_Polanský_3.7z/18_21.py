import random
for i in range(3):
    # NAJPRV 3 RANDOM PÍSMENKA KTORÉ SÚ VEĽKÉ
    print(chr(random.randint(ord('A'), ord('Z'), )), end='')
for i in range(2):
    # 2 RANDOM ČÍSLA
    print(random.randint(0, 9), end='')
for i in range(3):
    # 3 RANDOM PÍSMENKA KTORÉ SÚ MALÉ
    print(chr(random.randint(ord('a'), ord('z'), )), end='')
