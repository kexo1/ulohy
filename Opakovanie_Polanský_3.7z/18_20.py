import random
for i in range(8):
    # PRINTNE RANDOM PÍSMENKO OD HODNOTY a AŽ po z
    print(chr(random.randint(ord('a'), ord('z'))), end='')
