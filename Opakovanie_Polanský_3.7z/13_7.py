string_1, string_2 = input('Zadaj slovo: '), input('Zadaj 2. slovo: ')

# POROVNÁ KTORÉ SLOVO JE VAČŠIE
if len(string_1) > len(string_2):
    longer = string_1
    shorter = string_2
else:
    longer = string_2
    shorter = string_1

# PRINTNE PÍSMENKO ZA PÍSMENKOM
for i in range(len(longer)):
    print(longer[i], end='')

    # AK KRÁTKE SLOVO UŽ NEMÁ POČET PÍSMENOK AKO i TAK NEVYPISUJ MALÉ SLOVO
    if i < len(shorter):
        print(shorter[i], end='')
