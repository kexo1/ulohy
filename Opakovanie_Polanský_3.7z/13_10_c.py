import tkinter

canvas = tkinter.Canvas(height=100, width=500)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()


def text():
    x = 20
    canvas.delete('all')
    veta = str(entry1.get())
    for i in range(len(veta)):
        # MENÍ SA FARBA PODLA TOHO ČI JE i PÁRNE ALEBO NEPÁRE A TÝM PÁDOM ZÍSKA HODNOTU S TUPLE
        canvas.create_text(x, 35, text=veta[i], font='Arial 20', fill=('red', 'blue')[i % 2])
        x += 25


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
