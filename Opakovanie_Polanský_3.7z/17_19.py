# SPLTNEM TO NAJPRV NA PROTOKOL A URL
s = input('Zadajte URL adresu: ').split('/')

# SPLITNEM URL NA BODKY
domena = s[2].split('.')

# PRINTNE PROTOKOL S ODSTRÁNENOU DVOJBODKOU, POSLEDNÝ STRING V URL, CELÚ URL
print(f'a) {s[0][:-1]}\nb) {domena[len(domena)-1]}\nc) {s[2]}')
