string_1 = input('Zadaj slovo: ')

# TAK ISTO AKO MINULE, ODDElÍ SLOVÁ POMOCOU SLICE, PRINTNE NAJPRV KAŽDÉ 1 PÍSMENKO A POTOM KAŽDÉ DRUHÉ PÍSMENKO
print(string_1[::2] + ' ' + string_1[1::2])
