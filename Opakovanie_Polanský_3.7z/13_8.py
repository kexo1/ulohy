veta = input('Zadaj vetu: ')

# POROVNÁ KONCOVÉ PÍSMENKO
if veta[len(veta) - 1] == '!':
    print('Veta je rozkazovacia')
elif veta[len(veta) - 1] == '?':
    print('Veta je opytovacia')
elif veta[len(veta) - 1] == '.':
    print('Veta je oznamovacia')
else:
    print('Veta nemá znamienko')
