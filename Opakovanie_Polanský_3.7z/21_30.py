import random

s = input('Zadaj slovo: ')
# LIST KDE BUDÚ PÍSMENKÁ
s_list = []

# PRIDÁ PÍSMENKO PO PÍSMENKU
for i in s: s_list.append(i)

# 5 NÁHODNE ROZHÁDZANÝCH SLOV
for i in range(5):
    # POUŽIL SOM SHUFFLE KTORÉ TO SAMO ROZHÁĎZE
    random.shuffle(s_list)
    # A SPOJIL SOM SLOVO DOKOPY DO STRINGU
    print(f'{i+1}. Zamiešané slovo: {"".join(s_list)}')
