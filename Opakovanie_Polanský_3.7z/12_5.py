string_1, string_2 = input('Zadaj slovo: '), input('Zadaj 2. slovo: ')

# VYPÍŠE PÍSMENKO PO PÍSMENKU ZARADOM SLOVÁ
for i in range(len(string_1)): print(string_1[i] + string_2[i], end='')
