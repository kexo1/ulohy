s = ''
for i in range(ord('a'), ord('z')+1):
    # POSTUPNE PRIDÁVA PÍSMENKÁ S ČIARKOV
    s += chr(i) + ', '
print(s)
