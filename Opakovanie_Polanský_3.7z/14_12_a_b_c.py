veta = input('Zadaj vetu: ').split()

# POMOCOU max S PODMENKOV len RÝCHLO ZISÍ KTORÉ SLOVO JE NAJDLHŠIE
longest = max(veta, key=len)

# POČET SLOV CEZ LEN, DĹŽKA NAJVAČŠIEHO SLOVA TIEŽ CEZ LEN, PORADIE POMOCOU INDEX TÝM ŽE VYHLADÁ TO SLOVO V LISTE
print(f'Počet slov je: {len(veta)}\nNajdlhšie slovo je: {longest}\nDĺžka najväčšieho slova je {len(longest)}\nPoradie najväčšieho slova je: {veta.index(longest)+1}')

# ODSTRÁNI NAJDLHŠIE SLOVO ABY SA NEOPAKOVALO
veta.pop(veta.index(longest))

# AK SÚ ĎALŠIE ROVNAKO DLHÉ SLOVÁ, TAK SA VYPÍŠU
for slovo in veta:
    if len(slovo) == len(longest):
        print('Ďalšie najdlhšie slovo: ' + slovo)
