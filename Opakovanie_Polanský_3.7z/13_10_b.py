import tkinter

canvas = tkinter.Canvas(height=100, width=500)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()


def text():
    veta = str(entry1.get())
    canvas.delete('all')

    # VYDELÍ KOĽKO PRIEMERNE BY SA MALO PÍSMENKO OTÁČAŤ ABY NA KONCI BOLO ROVNAKO
    otacanie = 360 / len(veta)
    x = 20
    for i in range(len(veta)):
        # ČÍM VAČŠIE JE i TÝM SA TO VIAC BUDE OTÁČAŤ
        canvas.create_text(x, 50, text=veta[i], font='Arial 20 bold', fill='Blue', angle=i * otacanie + otacanie)
        x += 25


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
