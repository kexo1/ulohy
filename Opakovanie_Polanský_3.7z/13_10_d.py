import tkinter

canvas = tkinter.Canvas(width=500, height=100)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()


def text():
    x = 20
    canvas.delete('all')
    veta = str(entry1.get())
    for i in range(len(veta)):
        # PODOBNE AKO PRI MINULOM PRÍKLADE, OTÁČAJÚ SA PODLA TOHO ČI JE i PÁRNE ALEBO NEPÁRNE, AK 0 TAK SA NEOTOČÍ
        canvas.create_text(x, 35, text=veta[i], font='Arial 20', fill='blue', angle=(i % 2) * 180)
        x += 25


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
