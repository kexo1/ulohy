import tkinter

canvas = tkinter.Canvas(width=500, height=100)
canvas.pack()

# ENTRY
entry1 = tkinter.Entry()
entry1.pack()

# ZAČ. HODNOTY PRE PÍSMENKÁ
y = 30


def text():
    global y
    veta = str(entry1.get())
    canvas.delete('all')
    x = 20
    for i in veta:
        canvas.create_text(x, y, text=i, font='Arial 20 bold', fill='Blue')
        # POSUNIE SA X PRE ĎALŠIE PÍSMENKO
        x += 23
        # MENÍ SA VÝŠKA BUĎ NA 40 ALEBO 30
        y = 40 if y == 30 else 30


# BUTTON
button1 = tkinter.Button(text='OK', command=text)
button1.pack()

canvas.mainloop()
