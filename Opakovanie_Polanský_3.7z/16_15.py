s = input('Zadaj slovo: ')
for i in range(len(s)):
    # VYNÁSOBÍ POČET BODIEK POMOCOU DĹŽKY SLOVA ODPOČÍTANÝM i, SLICNEM SLOVO POMOCOU HODNOTY i, ČÍM VAČŠIE i, TÝM VIACEJ PÍSMENOK
    print('.' * (len(s) - i) + s[:i+1])
