# Cézarova_šifra
vstup = input('Zadaj text: ')
posun = [2, 3]

# POSUN O KOLKO ZOBERIE S LISTU
for kolko in posun:
    sifra = ''

    # PÍSMENKO PO PÍSMENKU
    for znak in vstup:
        # ZNAK KTORÝ BUDE POSUNUTÝ
        novyznak = znak

        # AK SA PÍSMENKO NACHÁDZA V TOMTO ROZMEDZÍ S PRIDANOU HODNOTOU kolko
        if 97 <= ord(znak) + kolko <= 122:
            novyznak = chr(ord(znak) + kolko)
        # INAK PÍSMENKO BUDE OD ZAČIATKU ABECEDY S PRIDANOU HODNOTOU kolko
        else:
            # VYPOČÍTA KOLKO MÁ PRIDAŤ OD PÍSMENA a (97)
            novyznak = chr(96 + ((ord(znak) + kolko) - 122))
        # PRIDÁ POSUNUTÝ ZNAK
        sifra += novyznak
    print(f'Posun o {kolko}: {sifra}')
