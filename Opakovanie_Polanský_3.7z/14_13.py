s = input('Zadaj slovo: ')
riadok = ''
for i in range(len(s)):
    print(riadok + s[i])
    # PRIDÁ MEDZERU
    riadok += ' '
