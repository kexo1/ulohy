s = ''
for i in range(10):
    # POSTUPNE PRIDÁVA ČÍSLA S ČIARKOV
    s += str(i) + ', '
print(s)
