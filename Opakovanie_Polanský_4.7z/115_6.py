import tkinter

canvas = tkinter.Canvas(width=300, height=600)
canvas.pack()

subor = open('slovenske_texty.txt', 'r', encoding='utf8')
frekvencia = {}
pocet_pismen = 0
for riadok in subor:
    nepovolene = [',', '.', '"', "'", '-', '(', ')', ' ']
    riadok = riadok.strip().upper()

    for nepovoleny in nepovolene:
        riadok = riadok.replace(nepovoleny, '')

    pocet_pismen += len(riadok)
    for znak in riadok:
        try:
            pocet = frekvencia[znak]
        except KeyError:
            pocet = 0
        frekvencia[znak] = pocet + 1
subor.close()

zoradene = sorted(frekvencia, key=frekvencia.get, reverse=True)


def vykresli(frekvencia, zoradene, pocet_pismen):
    y = 40
    x = 50
    canvas.create_text(x, 10, text='Graféma', font='Arial 12')
    canvas.create_text(x+70, 10, text='Výskyt', font='Arial 12')
    for znak in zoradene:
        canvas.create_text(x, y, text=znak, font='Arial 12')
        canvas.create_text(x + 70, y, text=round(frekvencia[znak] / pocet_pismen * 100, 2), font='Arial 12')
        y += 20
        if y // 600 == 1:
            y = 40
            x += 150
            canvas['width'] = x + 100
            canvas.create_text(x, 10, text='Graféma', font='Arial 12')
            canvas.create_text(x + 70, 10, text='Výskyt', font='Arial 12')


vykresli(frekvencia, zoradene, pocet_pismen)
canvas.mainloop()
