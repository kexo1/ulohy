subor = open('Student.csv', 'r', encoding='utf8')
osoby = []

priemerne_narodenie = 0
priemerny_rocnik = 0
priemerne_ukonceniestudia = 0

for riadok in subor:
    if 'Grade' not in riadok:
        info = riadok.split(',')
        osoba = {}
        osoba['meno'] = f'{info[2]} {info[3]}'
        osoba['rocnik'] = int(info[10])
        rok = info[12].split('/')
        osoba['roknarodenia'] = int(rok[2])
        osoba['ukonceniestudia'] = int(info[13])
        osoby.append(osoba)

        priemerny_rocnik += int(info[10])
        priemerne_narodenie += int(rok[2])
        priemerne_ukonceniestudia += int(info[13])
subor.close()

print('Počet žiakov je 86')
print(f'Priemerný ukončený ročník je {priemerny_rocnik//86}.')
print(f'Priemerný vek je {2021 - priemerne_narodenie//86}.')
print(f'Priemerný rok ukončenia štúdia je {priemerne_ukonceniestudia//86}.')
