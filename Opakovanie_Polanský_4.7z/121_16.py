subor = open('eu.txt', 'r', encoding='utf8')
subor_2 = open('slovnik_krajin.csv', 'w', encoding='utf8')
krajiny = subor.read().split(':')
subor.close()

for i in range(3):
    for krajina in krajiny:
        string = krajina.split('\n')

        if string[0] == '':
            string.pop(0)

        string = string[i].split(';')

        subor_2.write(f'{string[0]};')
    subor_2.write('\n\n')

jazyky = ['Slovenky', 'Česky', 'Anglicky']

for krajina in krajiny:

    c_rozloha = 0
    c_obyvatelov = 0
    c_miest = 0
    c_hustota = 0

    string = krajina.split(':')

    if string[0] == '':
        string.pop(0)

    for udaj in string:
        udaj = udaj.split(';')
        c_obyvatelov += int(udaj[2]) + int(udaj[8]) + int(udaj[14])
        c_rozloha += int(udaj[3]) + int(udaj[9]) + int(udaj[15])
        c_miest += int(udaj[5]) + int(udaj[11]) + int(udaj[17])
        c_hustota += int(udaj[4]) + int(udaj[10]) + int(udaj[16])
    print(f'{jazyky[0]} - počet obyvateľov: {c_obyvatelov}, celková rozloha: {c_rozloha}, počet miest: {c_miest}, celková hustota: {c_hustota}')
    jazyky.pop(0)
