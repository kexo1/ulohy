subor = open('osoby.txt', 'r', encoding='utf8')
osoby = []
for riadok in subor:
    info = riadok.split(';')
    osoba = {}
    osoba['meno'] = info[0]
    osoba['vyska'] = int((info[1]))
    osoba['roknarodenia'] = int(info[2])
    osoba['rodisko'] = info[3].strip()
    osoby.append(osoba)
print(osoby)
subor.close()

najmladsi = osoby[0].get('roknarodenia', None)
najvyssi = osoby[0].get('vyska', None)

for _ in osoby:
    najmladsi_temp = int(_.get('roknarodenia', None))
    if najmladsi_temp > najmladsi:
        najmladsi = najmladsi_temp
        najmladsi_meno = _.get('meno', None)

    najvyssi_temp = int(_.get('vyska', None))
    if najvyssi_temp > najvyssi:
        najvyssi = najvyssi_temp
        najvyssi_meno = _.get('meno', None)

print(f'Najmladší je {najmladsi_meno} s narodením v roku {najmladsi}')
print(f'Najvyšší je {najvyssi_meno} s výškou {najvyssi}\n')
print('Zistím mená zo zadaného mesta/roku narodenia (pre skončenie stlač len enter).')
hladat = input('Zadaj zadané mesto/roko narodenia: ')

while hladat != '':
    pocet = 0
    for _ in osoby:
        if hladat.isdigit():
            hodnota = _.get('roknarodenia', None)
            if str(hodnota) == hladat:
                hodnota_osoba = _.get('meno', None)
                pocet += 1
                print(f'{hodnota_osoba} sa narodil/a v roku {hladat}')
        else:
            hodnota = _.get('rodisko', None)
            if hodnota == hladat:
                pocet += 1
                hodnota_osoba = _.get('meno', None)
                print(f'{hodnota_osoba} žije v {hladat}')

    print(f'Počet osôb: {pocet}')
    hladat = input('Zadaj zadané mesto/roko narodenia: ')

