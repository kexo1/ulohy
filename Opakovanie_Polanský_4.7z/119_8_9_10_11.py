import random
import tkinter
import time

canvas = tkinter.Canvas(width=1380, height=800)
canvas.pack()

subor = open('slovne_hodnotenia.txt', 'r', encoding='utf8')
slova = subor.read().strip().replace(',', '').split()

vynimky_subor = open('vynimky.txt', 'r', encoding='utf8')
vynimky = vynimky_subor.read().split('\n')

vynimky_subor.close()
subor.close()

zoznam = []
pocet = 0

for slovo in slova:
    if len(slovo) >= 3 and slovo in vynimky:
        slovo = slovo.replace('"', '') \
            .replace(';', '') \
            .replace(',', '') \
            .replace('.', '') \
            .replace('?', '')

        try:
            pos = [i[0] for i in zoznam].index(slovo)
            zoznam[pos][1] += 1
        except ValueError:
            zoznam.append([slovo, 2])
        pocet += 1

zoznam.sort(key=lambda riadok: riadok[1], reverse=True)

subor = open('frekvencia.txt', 'w', encoding='utf8')
sifra = open('sifra.txt', 'w', encoding='utf8')

for slovo in zoznam:
    subor.write(f'{slovo[0]};{slovo[1]};{round(slovo[1] / pocet * 100, 2)}\n')
    slovo_list = []
    for i in slovo[0]: slovo_list.append(i)
    random.shuffle(slovo_list)
    sifra.write(slovo[0] + ';' + ''.join(slovo_list) + '\n')

subor.close()
sifra.close()


def obdlznik(poradie, vyska, farba):
    canvas.create_rectangle(poradie * 20 + 10, 700, poradie * 20 + 10 + 10, 300 - vyska * 20, fill=farba,
                            tags='obdlznik' + str(poradie))


poradie = 0
maxy = 800

for slovo, pocet in zoznam:
    obdlznik(poradie, pocet, 'blue')
    canvas.create_text(poradie * 20 + 15, maxy - 50, text=slovo, font='Arial 8', angle=90)
    poradie += 1


def mys(sur):
    global rozsvietene
    if rozsvietene is not None:
        try:
            canvas.delete('obdlznik' + str(rozsvietene))
            obdlznik(rozsvietene, zoznam[rozsvietene][1], 'blue')
        except IndexError:
            pass

    canvas.delete('info')
    if sur.y < 700 and 10 < sur.x < 70 * 20:
        ktory = (sur.x - 10) // 20
        try:
            canvas.delete('obdlznik' + str(ktory))
            obdlznik(ktory, zoznam[ktory][1], 'red')
            canvas.create_text(500, 100, text=zoznam[ktory][0] + '\n ' + str(zoznam[ktory][1]), font='Arial 30',
                               tags='info')
            rozsvietene = ktory
        except IndexError:
            pass


rozsvietene = None
canvas.bind('<Motion>', mys)

canvas.mainloop()
