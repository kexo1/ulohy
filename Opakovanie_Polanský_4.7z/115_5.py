import tkinter

canvas = tkinter.Canvas(width=600, height=320)
canvas.pack()

morse = {
    'A': '.-',
    'B': '-...',
    'C': '-.-.',
    'D': '-..',
    'E': '.',
    'F': '..-.',
    'G': '--.',
    'H': '....',
    'I': '..',
    'J': '.---',
    'K': '-.-',
    'L': '.-..',
    'M': '--',
    'N': '-.',
    'O': '---',
    'P': '.--.',
    'Q': '--.-',
    'R': '.-.',
    'S': '...',
    'T': '-',
    'U': '..-',
    'V': '...-',
    'W': '.--',
    'X': '-..-',
    'Y': '-.--',
    'Z': '--..',
    '1': '.----',
    '2': '..---',
    '3': '...--',
    '4': '....-',
    '5': '.....',
    '6': '-....',
    '7': '--...',
    '8': '---..',
    '9': '----.',
    '0': '-----',
    '.': '.-.-.-',
    ',': '--..--',
    '?': '..--..',
}


def kresli_stlpec(x, y, dx, dy, znaky):
    fa, fb = 'yellow', 'lightblue'
    for znak in znaky:
        canvas.create_rectangle(x, y, x + dx, y + dy, fill=fa)
        canvas.create_text(x + dx / 2, y + dy / 2, text=morse[znak.upper()] if x >= 300 else znak)
        y += dy
        fb, fa = fa, fb


velkost = 300
pocet_casti = 2
y = 10
dx = 50

subor = open('slovenske_texty.txt', 'r', encoding='utf8')
frekvencia = {}
for riadok in subor:
    riadok = riadok.lower()
    for znak in riadok:
        if 'a' <= znak <= 'z':
            frekvencia[znak] = frekvencia.get(znak, 0) + 1

subor.close()
zoradene = sorted(frekvencia, key=frekvencia.get, reverse=True)
spracovat = zoradene[:]

x = 10
while len(spracovat) > 0:
    kresli_stlpec(x, y, dx, velkost / pocet_casti, spracovat[:pocet_casti])
    x += 300
    kresli_stlpec(x, y, dx, velkost / pocet_casti, spracovat[:pocet_casti])
    x -= 300

    spracovat = spracovat[pocet_casti:]
    x += dx
    pocet_casti *= 2

canvas.mainloop()
