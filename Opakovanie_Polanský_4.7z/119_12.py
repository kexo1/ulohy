import random
import tkinter

canvas = tkinter.Canvas(width=600, height=600)
canvas.pack()

subor = open('slovne_hodnotenia.txt', 'r', encoding='utf8')
slova = subor.read().strip().split()
subor.close()

frekvencia = {}
pocet_slov = 0

for slovo in slova:
    nepovolene = [',', '.', '"', "'", '-', '(', ')', ' ']

    if len(slovo) >= 4:
        for nepovoleny in nepovolene:
            slovo = slovo.replace(nepovoleny, '')

        pocet_slov += 1
        try:
            pocet = frekvencia[slovo]
        except KeyError:
            pocet = 0
        frekvencia[slovo] = pocet + 1

colors = ('red', 'green', 'blue', 'yellow', 'orange', 'lightblue', 'lightgreen', 'brown', 'magenta', 'black')


def vykresli(slovo, pocet, pocet_slov):
    canvas.create_text(random.randint(0, 600), random.randint(0, 600), text=slovo,
                       font=f'Arial {int((pocet / pocet_slov) * 2500)}', angle=random.randint(0, 180),
                       fill=random.choice(colors))


for slovo, pocet in frekvencia.items():
    vykresli(slovo, pocet, pocet_slov)

canvas.mainloop()
