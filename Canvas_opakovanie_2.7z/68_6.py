import tkinter, random
canvas = tkinter.Canvas(bg='white', width=600, height=600)
canvas.pack()

x = 0

def titulky():
    global x

    # MAŽE TEXT
    canvas.delete('text')

    # DOZADU O 10
    x = x - 10

    # AK JE TO ZA BORDEROM, TAK HO VRÁTI NA ZAČIATOK
    if x == -30:
        x = 630

    # ZÍSKANIE TEXTU S ENTRY
    text = str(entry1.get())

    # VYKRESLENIE TEXTU
    canvas.create_text(x, 460, font='Arial 20 bold', text=text, tag='text')

    # UPDATE KAŽDÝCH 100 MILI-SEKÚND
    canvas.after(100, titulky)

entry1 = tkinter.Entry()
entry1.pack()

titulky()

