import tkinter, random
canvas = tkinter.Canvas(bg='white', width=600, height=600)
canvas.pack()


a = 10

def setric():
    global a
    canvas.delete('all')

    # ZÍSKA HODNOTU S ENTRY
    text = str(entry1.get())

    # RANDOM POZÍCIA
    x, y = random.randint(50, 550), random.randint(50, 550)

    # VYKRESLENIE TEXTU S nÁHODNIMY FARBAMI
    canvas.create_text(x, y, font='Arial 20 bold', text=text, angle=a, fill=random.choice(['blue','red','green', 'yellow', 'brown', 'orange']))

    # PRIDÁVA HODNOTU K UHLU, AK JE TO 90 STUPŇOV TAK NASTAVÍ ZNOVA NA 10
    if a != 90:
        a = a + 10
    else:
        a = 10
    canvas.after(1000, setric)

# FUNKCIA NA MAZANIE
def zmaz(event):
    canvas.delete("all")
    
entry1 = tkinter.Entry()
entry1.pack()

canvas.bind('<Button-1>', zmaz)

setric()
