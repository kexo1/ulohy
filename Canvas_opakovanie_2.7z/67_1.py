import tkinter, random
canvas = tkinter.Canvas(height = 1000, width = 1000)
canvas.pack()

def ziak(suradnice):
    # MENO ŽIAKA
    meno = str(entry1.get())
    y=suradnice.y
    x=suradnice.x

    # VYKRESLENIE ŽIAKA
    canvas.create_rectangle( x-30, y-30, x+30, y + 30)
    canvas.create_oval( x-30, y-30, x+30, y-90)
    canvas.create_text(x , y+ 38, font='Arial 10', text=meno)
 
# ZMAŽE PLOCHU
def maz():
    canvas.delete("all")

# BUTTON NA MAZANIE
button1 = tkinter.Button(text='Zmaž', command=maz)
button1.pack()    

# ENTRY NA MENO
entry1 = tkinter.Entry()
entry1.pack()

# BIND NA ZIAK
canvas.bind('<Button-1>', ziak)
