import tkinter, random
canvas = tkinter.Canvas(width= 500, height = 500)
canvas.pack()


a = 0
b = 0
pocet = 0

# VYKRESLENIE SEMAFORA
canvas.create_rectangle(200, 180, 270, 390, fill='black')

def semafory():
    a = random.randint(1, 5)
    canvas.delete("all")
    
    if a == 1:
        # IBA ČERVENÁ
        canvas.create_oval(205, 185, 265, 245, fill='red')
    if a == 2:
        # IBA ŽLTÁ
        canvas.create_oval(205, 255, 265, 315, fill='yellow')
    if a == 3:
        # IBA ZELENÁ
        canvas.create_oval(205, 325, 265, 385, fill='lime')
    if a == 4:
        # ČERVENÁ A ŽLTÁ
        canvas.create_oval(205, 185, 265, 245, fill='red')
        canvas.create_oval(205, 255, 265, 315, fill='yellow')
    if a == 5:
        # VŠETKY SVETlÁ
        canvas.create_oval(205, 185, 265, 245, fill='red')
        canvas.create_oval(205, 255, 265, 315, fill='yellow')
        canvas.create_oval(205, 325, 265, 385, fill='lime')
        
    # UPDATE KAŽDÚ SEKUNDU
    canvas.after(1000, semafory)
    
semafory()
