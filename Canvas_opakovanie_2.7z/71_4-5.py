import random, tkinter, time
canvas = tkinter.Canvas(height = 500, width = 500)
canvas.pack()

pocetbodov = 0
y = -40

# FUNKCIA REAGUJÚCA NA KLIKY
def klik(suradnice):
    global pocetbodov

    # AK SLOVO PADLO POD HRANICU A EŠTE SI NEVYHRAL
    if suradnice != 'padlo' and vyhra == 0:

        # ZÍSKA SÚRADNICE KLIKU
        x = suradnice.x

        # POROVNÁ ČI SI KLIKOL SA SLOVO
        if x_random < x < x_random + 80 and y < suradnice.y < y + 30:

            # AK SLOVO BOLO BEZ CHYBY TAK PRIDÁ BOD, INAK ODODBERE 2 BODY
            if chybove == 0:
                pocetbodov += 1
            else:
                pocetbodov -= 2

            # ZVOLÁ FUNKCIU KTORÁ VYGENERUJE ĎALŠIE SLOVO
            vygeneruj(pocetbodov)
    elif vyhra == 0:

        # AK NESPRÁVNE SLOVO PADLO POD HRANICU, PRIPOČÍTA BOD
        if chybove == 1:
            pocetbodov += 1
        else:
            pocetbodov -= 2

        # ZVOLÁ FUNKCIU KTORÁ VYGENERUJE ĎALŠIE SLOVO
        vygeneruj(pocetbodov)

canvas.bind('<Button-1>', klik)

def vygeneruj(pocetbodov):
    global y, chybove, x_random, vyhra

    # AK SI ZÍSKAL 10 BODOV, NASTAVÍ PREMENNÚ 'vyhra' KTORÁ ZASTAVÍ FUNKCIE KLIK A UPDATE
    if pocetbodov > 9:
        vyhra = 1

        # VYBERE VÝHRU
        odmeny = random.choice(('tablet', 'čokoládu', 'medailu', 'lístky do kina', 'knihu', 'tričko'))
        canvas.delete("all")

        # VYKRESLÍ POČET BODOV
        canvas.create_text(30, 15, font='Arial 20 bold', text = pocetbodov)

        # VYPÍŠE GRATULÁCIU
        canvas.create_text(250, 15, font='Arial 10 bold', text = 'Gratulujem, získali ste ' + odmeny)
    else:
        # VYMAŽE POČET BODOV
        canvas.delete('pocet')

        # VYKRESLÍ POČET BODOV
        canvas.create_text(30, 15, font='Arial 20 bold', text = pocetbodov, tags = 'pocet')

        # VYBERIE RANDOM X POZÍCIU S KTOREJ BUDE SLOVO PADAŤ
        x_random = random.randint(0, 420)

        # VYBERIE ČI MÁ BYŤ SLOVO CHYBOVÉ
        chybove = random.randint(0, 1)

        # ZVOLÁ FUNKCIU KTORÁ OTVORÍ JEDEN ZO SÚBOROV PODĽA HODNOTY 'chybove'
        slovo = ziskaj_slovo(chybove)

        # NASTAVÍ y PADAJÚCEHO TEXTU
        y = -40

        # HODNOTU NASTAVÍ NA 0 = NEVYHRAL ZATIAĽ
        vyhra = 0

        # PREDÁ PREMENNÉ DO FUNKCIE UPDATE
        update(vyhra, slovo)

def pozicia(y, slovo):
    # VYMAŽE PADAJÚCI TEXT
    canvas.delete('text')

    # VYKRESLÍ PADAJÚCI TEXT
    canvas.create_text(x_random + 40, y + 20, text = slovo, font = 'Arial 10 bold', tags = 'text')


def ziskaj_slovo(chybove):

    # AK CHYBOVE JE 0 (SLOVO BEZ CHYBY) TAK OTVORÍ SÚBOR ZO SPRÁVNYMI SLOVAMI, INAK Z NESPRÁVNIMI
    if chybove == 0:
        s = 'slova.txt'
    else:
        s = 'zleslova.txt'

    with open(s, 'r', encoding="utf8") as f:
        # ZÍSKA TEXT S ODSEKMI
        read = f.read()

        # SPLITNE ODSEKY
        array = read.split('\n')

        # VYBERIE NÁHODNÉ SLOVO ZO SÚBORU
        return random.choice(array)
        
# POUŽIL SOM RADŠEJ CANVAS.UPDATE AKO AFTER, PRETOŽE AFTER JE NESTABILNÝ KEĎ VYVOLÁM FUNKCIU S AFTEROM
def update(vyhra, slovo):
    global y

    # UPDATE KAŽDÝCH 0.025 SEKÚNDž
    speed = 1.5/60
    rtime = time.time()

    # AK SI NEVYHRAL
    while vyhra == 0:
        # KONTROLUJE UPDATE ČAS
        if time.time()-rtime >= speed:
            rtime = time.time()

            # VYVOLÁ FUNKCIU S TEXTOM
            pozicia(y, slovo)

            # UPDATNE CANVAS
            canvas.update()

            # PRIDÁ 5 ABY SLOVO PADALO
            y += 5

            # AK POD HRANICOU, TAK DO KLIK POŠLEM STRING 'padlo' KTORÝ PRIDÁ BODY ZA CHYBOVÉ PADNUTÉ SLOVO
            if y > 500:
                klik('padlo')

# VYGENERUJE ZAČ. PREMENNÉ
vygeneruj(0)

# ZAČNE UPDATE FUNKCIU
update(0, ziskaj_slovo(random.randint(0, 1)))


        







