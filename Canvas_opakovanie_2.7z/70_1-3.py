import random


def nahodna_veta():
    kedy = random.choice(('Včera', 'Ráno', 'Poobede', 'Večer', 'O polnoci'))
    cislo = random.randint(1, 2)
    if cislo == 1:
        # MUŽSKÉ
        kto = random.choice(('kamarát', 'spolužiak', 'súdruh', 'Andrej', 'Roman', 'Matej', 'Nikolas', 'Marcus', 'Filip',
                      'Marek', 'Jano', 'Samo', 'Panzerkampfwagen Tiger I'))
    else:
        # ŽENSKÉ
        kto = random.choice(('kamarátka', 'spolužiačka', 'Alica', 'Zuzana', 'Uršula', 'Eva', 'Lucia', 'Monika'))

    corobil = random.choice(('videl', 'prezradil', 'povedal', 'napísal', 'zistil',
                      'nakreslil', 'vyrobil', 'zničil', 'opravil', 'vyrobil'))
    ake = random.choice(('veľké', 'malé', 'obrovské', 'drobné', 'smutné', 'veselé', 'nepekné', 'výborné'))
    co = random.choice(('tajomstvo', 'prekvapenie', 'predsavzatie', 'koláče'))

    # KONTROLA ČI SA SLOVÁ HODIA K SEBE ABY VYTVORILO NORMÁLNU VETU
    if co == 'tajomstvo':
        ake = ''

    if corobil == 'napísal' and co == 'tajomstvo' or corobil == 'napísal' and co == 'prekvapenie':
        co = 'predsavzatie'

    if corobil == 'vyrobil' and co == 'tajomstvo':
        corobil = 'povedal'

    if corobil == 'nakreslil' and co == 'prekvapenie' or corobil == 'nakreslil' and co == 'tajomstvo':
        corobil = 'prekvapenie'

    if corobil == 'opravil' or corobil == 'prezdradil':
        ake = 'zničené'

    if co == 'predsavzatie' and corobil == 'vyrobil':
        corobil = 'napísal'

    if co == 'koláče' and corobil == 'zistil' or co == 'koláče' and corobil == 'povedal' or co == 'koláče' and corobil == 'prezdradil' or co == 'koláče' and corobil == 'napísal':
        corobil = 'vyrobil'

    # AK ŽENSKÉ TAK PRIDAJ 'a'
    if cislo == 2:
        corobil += 'a'
    spojene = kedy + ' ' + kto + ' ' + corobil + ' ' + ake + ' ' + co + '.'
    print(spojene)


for i in range(20):
    nahodna_veta()
