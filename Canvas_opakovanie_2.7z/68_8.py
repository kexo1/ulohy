import tkinter, random
canvas = tkinter.Canvas(height=400, width=400)
canvas.pack()


stop = 1

# ZAČ. POZÍCIE BOSORIEK
pozicie_x = [120, 250]
pozicie_y = [50, 50]

def bosorky():
    global stop, pozicie

    # MAZANIE
    canvas.delete("all")

    # LOOP 2x LEBO 2 BOSORKY
    for j in range(2):

        # RANDOM SKOK
        skok = random.randint(1, 10)

        # ZÍSKANIE POZÍCÍ X, Y JEDNEJ Z BOSORIEK
        x, y = pozicie_x[j],  pozicie_y[j]
        metla_vyska = 0

        # PRIDANIE SKOKU K DANEJ BOSORKE
        pozicie_y[j] += skok

        # VYKRESLENIE METLY
        for i in range(1, 10):
            canvas.create_line(pozicie_x[j] - 40, pozicie_y[j] + metla_vyska, pozicie_x[j], pozicie_y[j] + 40)
            metla_vyska += 8

        # VYKRESLENIE TYČI NA METLI
        canvas.create_line(pozicie_x[j], pozicie_y[j] + 40, pozicie_x[j] + 50, pozicie_y[j] + 40)

        # VYKRESLENIE TELA
        canvas.create_rectangle(pozicie_x[j] + 10, pozicie_y[j] - 20, pozicie_x[j] + 40, pozicie_y[j] + 60)

        # VYKRESLENIE HLAVY
        canvas.create_oval(pozicie_x[j] + 10, pozicie_y[j] - 50, pozicie_x[j] + 40, pozicie_y[j] - 20)

    # AK BOSORKA NALAVO POD 400
    if pozicie_y[0] + 60 >= 400 and stop == 1:
        stop = 0
        canvas.create_text(200, 10, font='Arial 10', text='Bosorka na lavo vyhrala')

    # AK BOSORKA NAPRAVO POD 400
    if pozicie_y[1] + 60 >= 400 and stop == 1:
        stop = 0
        canvas.create_text(200, 10, font='Arial 10', text='Bosorka na pravo vyhrala')

    # AK NEJAKÁ BOSORKA VYHRALA, STOP CANVAS AFTER
    if stop == 1:
        canvas.after(100, bosorky)
    
bosorky()


