import tkinter, random
canvas = tkinter.Canvas(width= 500, height = 500)
canvas.pack()

pocet = 0

# VYKRESLENIE KOCIEK
canvas.create_rectangle(100, 220, 160, 280)
canvas.create_rectangle(340, 220, 400, 280)
    

def kocky():
    global a, b
    # VYMAZANIE ČÍSEL V KOCKE
    canvas.delete('cisla')

    # RANDOM HODNOTY V KOCKÁCH
    a, b = random.randint(1, 6), random.randint(1, 6)

    # VYKRESLENIE RANDOM HODNOTY
    canvas.create_text(130, 250, text = a, tags='cisla')
    canvas.create_text(370, 250, text = b, tags='cisla')

    # UPDATE KAŽDÚ SEKUNDU
    canvas.after(1000, kocky)

def pocetbodov():
    global pocet

    # VYMAZANIE BODOV
    canvas.delete('pocet_bodov')

    # AK ROVNÉ TAK PRIDAJ 2
    if a == b:
        pocet = pocet + 2
    else:
        pocet = pocet - 1

    # VYKRESLENIE POČTU BODOV
    canvas.create_text(20, 10, text = pocet, font='Arial 15 bold', tags='pocet_bodov')

kocky()
button = tkinter.Button(text='Rovnaké', command=pocetbodov)
button.pack()

        



