import tkinter, random
canvas = tkinter.Canvas(width= '600', height= '400')
canvas.pack()

# VYKRESLENIE MORA
canvas.create_rectangle(0, 250, 600 , 400, outline='', fill='blue')

def lod_balon(suradnice):
    x = suradnice.x
    y = suradnice.y

    # POROVNANIE VÝŠKY
    if 250 < y < 400:
        
        # VYKRESLENIE LODE
        canvas.create_line(x-30, y, x+30, y, width=2)
        canvas.create_line(x-30, y, x-50, y-20, width=2)
        canvas.create_line(x+30, y, x+50, y-20, width=2)
        canvas.create_line(x+50, y-20, x-50, y-20, width=2)
        canvas.create_line(x, y-20, x, y-70, width=2)
        canvas.create_line(x, y-70, x+20, y-45, x, y-35, width=2)

    else:
        
        # VYKRESLENIE BALÓNA
        canvas.create_rectangle(x-10, y-10, x+10, y+10, width=2)
        canvas.create_oval(x-20, y-25, x+20, y-65, width=2)
        canvas.create_line(x, y-10, x+18, y-35, width=2)
        canvas.create_line(x, y-10, x-18, y-35, width=2)
        
canvas.bind('<Button-1>', lod_balon)
