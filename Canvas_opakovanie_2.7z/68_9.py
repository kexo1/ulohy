import tkinter
canvas = tkinter.Canvas(height=400, width=400)
canvas.pack()

x = 0
x1 = 0
y = 20
y1 = 30
y3 = 0
y2 = 0
b = 0
p = 1
a = 0
b = 1

def petrihomiska():
    global x, x1, y2, y, y1, y3, a, b
    canvas.delete("all")

    # VYKRESLENIE PETRIHO MISKY
    canvas.create_oval(50, 300, 330, 330)
    canvas.create_oval(50, 320, 330, 350)
    canvas.create_line(50, 314, 50, 338)
    canvas.create_line(330, 314, 330, 338)

    # POČET BODOV
    canvas.create_text(380, 20, font='Arial 10 bold', text=a)

    # MLÁKA KTORÁ MENÍ HODNOTU
    canvas.create_oval(x, y2, x1, y3, fill='blue', outline='')
    y = y + 5
    y1 = y + 5

    # VYKRESLENIE KVAPKY
    canvas.create_oval(185, y, 195, y1, fill='blue', outline='')

    # AK NENI PAUZNUTÉ TAK POKRAČUJ
    if p == 1:

        # AK MLÁKA PRESIAHLA HODNOTU X TAK STOP
        if x1 < 330:
            canvas.after(1, petrihomiska)

    # AK MLÁKA DOPADLA TAK VYPLŇ MISKU
    if y > 330:

        # AK PRVÁ KVAPKA PADLA, ZADAJ HODNOTY PRVEJ MLÁKY
        if b == 1:
            x = 160
            x1 = 220
            y2 = 330
            y3 = 340
            
        b = 0

        # POČET BODOV
        a = a + 1

        # ZVAČŠOVANIE MLÁKY
        y = 20
        y1 = 30
        x = x - 10
        y2 = y2 - 0.62
        x1 = x1 + 10
        y3 = y3 + 0.62


        
petrihomiska()

# FUNKCIA NA PAUZNUTIE
def pauza(event):
    global p
    if p==0:
        p=1
        petrihomiska()
    else:
        p=0
    print(p)


canvas.bind_all('p', pauza)


