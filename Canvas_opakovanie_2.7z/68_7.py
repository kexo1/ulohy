import tkinter, random
canvas = tkinter.Canvas(width= 500, height = 500)
canvas.pack()

# VYBERIE NAHODNÝ KÁBEL
nahodny_kabel = random.randint(1, 4)

# KÁBEL KTORÝ BOL KLIKNUTÝ
vybrany = -1

# PREMENNÁ KTORÁ ZABRÁNI KLIKANIE NA TLAČÍTKA A URČUJE POČET POKUSOV (MAX 3 NESPRÁVNE KLIKY)
stop_tlacitka = 0

# ČAS V MS
cas = 600

def casovac():
    global cas, stop_tlacitka
    # MAZANIE ČASOVAČU
    canvas.delete('casovac')

    # ODPOČET
    cas = cas - 1.2
    
    # ČASOVAČ 
    canvas.create_text(250, 100, text = cas//10, font = 'Arial 60 bold', fill='red', tags='casovac')

    # AK NAHODNÝ KÁBEL JE ROVNÝ KLIKNUTÉMU TAK VYPÍŠE TEXT A ZABLOKUJE TLAČÍTKA
    if nahodny_kabel == vybrany:
        canvas.create_text(250, 200, text = 'Bomba zneškodnená', font = 'Arial 20 bold', fill='red')
        stop_tlacitka = 3

    # AK SI ZLE KLIKOL A stop_tlacitka JE NA 0 (ABY SA HODNOTA SAMÁ NEPRIDÁVALA)
    elif nahodny_kabel != vybrany and stop_tlacitka != 0:

        # SPRAVIL SI 3 POKUSY, BOMBA VYBUCHNE, INAK POKRAČUJE ČASOVAČ
        if stop_tlacitka == 3:
            canvas.create_text(250, 200, text = 'Bomba vybuchla', font = 'Arial 20 bold', fill='red')
        else:
            canvas.after(100, casovac)
        
    # AK ČASOVAČ JE 0 TAK SKONČÍ
    elif cas == 0:
        canvas.create_text(250, 200, text = 'Bomba vybuchla', font = 'Arial 20 bold', fill='red')

    # AFTER KAŽDÝCH 100 MILISKEÚND ABY BOLI PREMENNÉ ZASLANÉ RÝCHLEJŠIE
    else:
        canvas.after(100, casovac)
        
# TLAČÍTKA MENIA HODNOTY VYBRATÉHO KÁBLU A KONTROLUJE ČI SÚ TLAČÍTKA POVOLENEÉ A ČI EŠTE SÚ EŠTE POKUSY
def kabel_1():
    global vybrany, stop_tlacitka
    if stop_tlacitka < 4:
        vybrany = 1
        stop_tlacitka += 1
    
def kabel_2():
    global vybrany, stop_tlacitka
    if stop_tlacitka < 4:
        vybrany = 2
        stop_tlacitka += 1
    
def kabel_3():
    global vybrany, stop_tlacitka
    if stop_tlacitka < 4:
        vybrany = 3
        stop_tlacitka += 1
    
def kabel_4():
    global vybrany, stop_tlacitka
    if stop_tlacitka < 4:
        vybrany = 4
        stop_tlacitka += 1

casovac()

button1 = tkinter.Button(text='Modrý káblik', command=kabel_1)
button1.pack()

button2 = tkinter.Button(text='Červený káblik', command=kabel_2)
button2.pack()

button3 = tkinter.Button(text='Žltý káblik', command=kabel_3)
button3.pack()

button4 = tkinter.Button(text='Zelený káblik', command=kabel_4)
button4.pack()

        



