string = input('Zadaj vetu: ')
abeceda = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ '

freq = {}

for pismeno in string:
    if abeceda.index(pismeno) == 26:
        print('0 ', end='')
    else:
        for i in range(abeceda.index(pismeno) % 3 + 1):
            print(abeceda.index(pismeno) // 3 + 1, end='')
        print(' ', end='')

    try:
        pocet = freq[abeceda.index(pismeno) // 3 + 1]
    except KeyError:
        pocet = 0

    if abeceda.index(pismeno) == 26:
        freq[abeceda.index(pismeno) // 3 + 1] = pocet + 1
    else:
        freq[abeceda.index(pismeno) // 3 + 1] = pocet + abeceda.index(pismeno) % 3 + 1
maxy = max(freq.values())

print(f'\nNajčastejšie zvolené políčka: {[k for k,v in freq.items() if v == maxy]}')
