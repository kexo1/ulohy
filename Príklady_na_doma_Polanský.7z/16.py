file = open('mena_zamestnancov.txt', 'r').read().split('\n')
name, surname = file[:4], file[4:]
longest_n, longest_s = max(name, key=len), max(surname, key=len)

file = open('vystup.txt', 'w')
for i in range(len(name)):
    file.write(f'{name[i]} {" "*(len(longest_n) - len(name[i]))}{surname[i]}\n')

print(f'Počet mien: {len(name)}')
print(f'Najdlhšie krstné meno: {longest_n}')
print(f'Najdlhšie priezvisko: {longest_s}')
