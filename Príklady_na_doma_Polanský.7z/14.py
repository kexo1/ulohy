file = open('skok_do_dialky.txt', 'r').read().split('\n')

country = {
    'SVE': 'Švédsko',
    'RUS': 'Rusko',
    'FIN': 'Fínsko',
    'USA': 'Spojené Štáty Americké',
    'HUN': 'Mongoli',
    'FRA': 'Francúzsko'
}

count = {}
jump_best = {}

for string in file:
    string = string.split()
    jump_best[string[0]] = 0

    for jump in string[2:]:
        if int(jump) > jump_best[string[0]]:
            jump_best[string[0]] = int(jump)

    number = 1
    try:
        number = count[country.get(string[1])]
        number += 1
    except KeyError:
        country[country.get(string[1])] = number

    count[country.get(string[1])] = number

for string in count:
    print(f'Krajina: {string}, Počet: {count[string]}')

maxy = max(jump_best.values())
print(f'\nNajdlhšie skoky: {[k for k,v in jump_best.items() if v == maxy]}')